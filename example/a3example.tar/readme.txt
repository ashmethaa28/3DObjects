
Sample of the drawing program for assignment 3.

-run the code by clicking on index.html
-the loaddata.js file contains a sample object and texture which will be displayed
-the object is a cube which is defined by the vertex, normals, texture coordinates, and the indices data
-the cube has a small texture of four coloured squares drawn on it

-when you write the assignment you will need to load the formatted data from your C/Python program into the functions contained in the loaddata.js file
-you should not need to edit the webgl-demo.js file 
-you are not required to write css with the assignment

